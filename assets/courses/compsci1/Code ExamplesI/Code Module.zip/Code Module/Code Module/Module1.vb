Option Explicit On
Module Module1
    Public lp As Integer

    Public Sub mysub()
        lp = 12
    End Sub

End Module
