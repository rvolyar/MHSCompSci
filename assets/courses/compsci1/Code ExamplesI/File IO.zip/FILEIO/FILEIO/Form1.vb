Imports System.io

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim reader As StreamReader

        reader = New StreamReader("C:\Documents and Settings\dfarrell\My Documents\test.txt")


        Do While reader.Peek <> -1
            ListBox1.Items.Add(reader.ReadLine)
        Loop

        ' reader.Read()
        ' reader.ReadToEnd()


        reader.Close()


        ' THE FOLLOWING READS IN A LINE AND PARSES THE LINE BY SEPERATING WORDS USING A COMMA
        ' HERE IS THE SAMPLE FILE CONTENTS:
        ' one,two,three,
        ' four,
        ' five,
        ' six,


        reader = New StreamReader("C:\Documents and Settings\dfarrell\My Documents\test.txt")

        Dim linein As String = ""
        Dim word As String = ""
        Dim letter As String = ""
        Dim z, l As Integer

        Do While reader.Peek <> -1

            linein = reader.ReadLine
            l = linein.Length
            z = 1
            Do While z <= l
                letter = Mid(linein, z, 1)
                If letter <> "," Then
                    word = word + letter
                Else
                    ListBox1.Items.Add(word)
                    word = ""
                End If
                z += 1
            Loop

            word = ""

        Loop




    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim writer As StreamWriter
        writer = New StreamWriter("C:\Documents and Settings\dfarrell\My Documents\testwrite.txt")

        writer.WriteLine("vnierhehiehoehieuoer")
        writer.Write("one")
        writer.Write("two")
        writer.Close()


    End Sub

   
End Class
