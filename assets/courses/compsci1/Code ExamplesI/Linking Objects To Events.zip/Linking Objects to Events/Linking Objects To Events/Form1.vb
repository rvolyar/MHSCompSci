Public Class Form1

    ' will hold arrays of buttons and textboxes
    Dim mybuttons As ArrayList
    'Dim mytext As ArrayList

    '  LINKED ALL THREE BUTTONS TO THE SAME CLICKED EVENT
    ' EVALUATE the SENDER Argument to see WHICH button was clicked
    Private Sub AllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click, Button2.Click, Button3.Click

        If sender.Equals(Button1) Then
            Label1.Text = "button 1 clicked"
        ElseIf sender.Equals(Button2) Then
            Label1.Text = "button 2 clicked"
        Else
            Label1.Text = "button 3 clicked"
        End If

        '  THIS CODE WILL LOOP THRU the array of buttons and match
        '  each with the actual button clicked, when there is a match
        ' display a message in the label and in the ASSOCIATED
        ' TEXTBOX
        Dim obj As Object
        Dim i As Integer
        For Each obj In mybuttons
            ' we know they are all buttons but this 
            ' shows we can have heterogeneous objects
            ' in an array (if they are within the same hierarchy
            i = mybuttons.IndexOf(obj)
            If TypeOf obj Is Button Then
                Dim mb As Button
                mb = CType(obj, Button)
                If sender.Equals(mb) Then
                    Select Case mb.Text
                        Case "Button1"
                            TextBox1.Text = "XXXXXXXXXXX"
                        Case "Button2"
                            TextBox2.Text = "XXXXXXXXXXX"
                        Case Else
                            TextBox3.Text = "XXXXXXXXXXX"
                    End Select


                End If
            End If
        Next


    End Sub

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        ' Build arrays of the buttons and textboxes that I want to 
        ' work like a VB control array
        mybuttons = New ArrayList
        ' mytext = New ArrayList
        mybuttons.Add(Button1)
        mybuttons.Add(Button2)
        mybuttons.Add(Button3)
        '  mytext.Add(TextBox1)
        '  mytext.Add(TextBox2)
        '  mytext.Add(TextBox3)


    End Sub

  
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        
    End Sub
End Class
