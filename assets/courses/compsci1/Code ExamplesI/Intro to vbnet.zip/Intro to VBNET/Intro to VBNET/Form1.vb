Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "OK" Then
            Label1.Text = "OK Also"
        Else
            Label1.Text = "Not OK"
        End If

        LinkLabel1.Visible = True
        Timer1.Enabled = True

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LinkLabel1.Visible = False
        TextBox2.Text = "This application highlights the following:" + vbNewLine + _
        "Use Form Load, Textboxes, Labels (text not caption property)" + vbNewLine + _
        "ProgressBar, User Defined SubRoutine, LINKTEXT" + vbNewLine + _
        "Try/Catch,  Use of Object's Propertys & Methods (sub Routines)" + vbNewLine + _
        "If Then Statements,  TIMER OBJECT"
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        If ProgressBar1.Value >= 99 Then
            ProgressBar1.Enabled = False
            Label1.Text = "Processing Completed"
            Exit Sub
        End If
        ProgressBar1.Value += 10

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim target As String
        '  WHEN CONNECTED TO INTERNET, THANGE TO TARGET = LINKLABEL
        target = "C:\Documents and Settings\Dave\My Documents\Dave HTML\MHS COM SCI FACULTY\index.html"
        'target = LinkLabel1.Text  'CType(e.Link.LinkData, String)
        Try
            VisitLink(target)
        Catch ex As Exception
            ' The error message
            MessageBox.Show("Unable to open link that was clicked.")
        End Try

        ' If the value looks like a URL, navigate to it.
        ' Otherwise, display it in a message box.
        '   If (Nothing <> target) And (target.StartsWith("www")) Then
        '' System.Diagnostics.Process.Start(target)
        '   Else
        ''  MessageBox.Show(("Item clicked: " + target))
        '  End If


    End Sub

    Sub VisitLink(ByVal target As String)
        ' Change the color of the link text by setting LinkVisited 
        ' to True.
        LinkLabel1.LinkVisited = True
        ' Call the Process.Start method to open the default browser 
        ' with a URL:
        System.Diagnostics.Process.Start(target)
    End Sub

End Class
