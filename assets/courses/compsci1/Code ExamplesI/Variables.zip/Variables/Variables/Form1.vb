Public Class Form1
    Const pi As Double = 3.14159
    Dim area, cir As Double
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim r As Double
        r = Val(TextBox1.Text)
        cir = 2 * pi * r
        area = pi * r ^ 2
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox2.Text = area
        TextBox3.Text = cir
    End Sub
End Class
