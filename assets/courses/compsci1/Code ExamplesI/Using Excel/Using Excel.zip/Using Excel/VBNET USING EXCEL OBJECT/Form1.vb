Public Class Form1

    'dimension excel application, workbook and worksheet as objects
    Dim exapp As Object, _
        exwks As Object, _
        exwkb As Object

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        exapp = CreateObject("Excel.Application")
        exwkb = exapp.Workbooks.Add
        exwks = exwkb.Worksheets(1)
        'make spreadsheet visible
        exapp.Visible = True

        With exwks
            .Cells(1, 2).Value = "hello1"
            .Cells(2, 3).Value = 1292
            .Cells(2, 2).Value = "hello1"
            .Cells(3, 3).Value = Format$(1292, "#############")
            .Cells(4, 2).Value = "hello1"
            .Cells(2, 4).Value = Format$(1292, "#############")
            .Cells(1, 5).Value = "hello1"
            .Cells(2, 6).Value = Format$(1292, "#############")
        End With

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'save the worksheet
        exwks.SaveAs("c:\test.xls")
        'print the excel spreadsheet
        exapp.ActiveWindow.SelectedSheets.PrintOut(Copies:=1)
        'close excel
        exapp.Quit()
        'release the objects
        exapp = Nothing
        exwkb = Nothing
        exwks = Nothing
        'Set CEvalRec = Nothing
        'close the result set
        'rdo_resultset.Close

        'sets a refrence to the result set to null and frees up memory
        'Set rdo_resultset = Nothing
    End Sub
End Class

