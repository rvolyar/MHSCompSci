Public Class Form1
    Dim myAL As ArrayList = New ArrayList

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim z(0 To 4) As String
        Dim xx(3, 3) As Integer
        Dim n, y() As Integer
        Dim cc(2) As Integer
        ReDim z(12)
        n = 5
        ReDim Preserve y(n)
        z(2) = "sss"
        xx(2, 2) = 23



        y(2) = 333

        n = LBound(z)
        Button1.Text = y(2)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim xxx As employee
        xxx.firstName = "aaa"
        Button2.Text = xxx.firstName

        Dim x(2) As employee

        ReDim x(0).workPhone(2)
        x(0).workPhone(1) = 2222

        Button2.Text = x(0).workPhone(1)


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim cc As Integer = 10
        myAL.Add(cc)
        myAL.Add(20)
        myAL.Add(15)
        myAL.Add(35)
        myAL.Add(5)

        countAL()

        myAL.Remove(20)

        countAL()

        TextBox1.Text = myAL.Contains(15)

        myAL.Item(0) = 40

        countAL()

        myAL.Sort()

        TextBox2.Text = myAL.BinarySearch(40)

        TextBox3.Text = myAL(0).Equals(myAL(0))

        myAL.Clear()

        countAL()


    End Sub

    Public Sub countAL()
        Button3.Text = "0"
        Dim z As Integer
        z = 0
        Do While z < myAL.Count
            Button3.Text = Val(Button3.Text) + myAL.Item(z)
            z += 1
        Loop


    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class
