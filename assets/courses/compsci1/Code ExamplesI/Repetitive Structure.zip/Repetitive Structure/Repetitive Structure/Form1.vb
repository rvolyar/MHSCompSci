Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim li_count As Integer

        ' this code executes 3 times
        For li_count = 1 To 3 Step 1
            TextBox1.Text = li_count
        Next li_count




    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim numbers(5) As Integer
        'numbers = New Integer() {}
        numbers(0) = 21
        numbers(1) = 22
        numbers(2) = 34
        numbers(3) = 45
        numbers(4) = 55

        Dim sum As Integer = 0
        For Each elt As Integer In numbers
            sum += elt
            ' The following statement works only on the local copy
            ' of the array, not on the original array.
            elt = 0
        Next elt
        TextBox2.Text = sum


    End Sub
End Class
