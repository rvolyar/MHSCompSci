Public Structure employee
    Public fname As String
    Public mi As String
    Public lname As String
    Public phones() As String
    Public rate As Double
    Public hours As Double
    Public salary As Double

    Public Sub calcsalary()
        salary = rate * hours
    End Sub

   
End Structure