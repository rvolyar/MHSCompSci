Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim z As employee
        ReDim z.phones(3)

        z.phones(0) = "111-222-3333"

        z.fname = "sally"
        z.hours = 10
        z.rate = 5

        z.calcsalary()

        Button1.Text = z.salary & " " & z.phones(0)


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim s(3) As employee

        s(0).fname = "harry"
        Button2.Text = s(0).fname

    End Sub
End Class
