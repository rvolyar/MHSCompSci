Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim s, r As String
        Dim i As Integer
        s = "SallyJoeBob"
        StrConv(s, VbStrConv.ProperCase)
        r = Microsoft.VisualBasic.Left(s, 2)
        r = Mid(s, 2, 5)
        TextBox1.Text = LCase(TextBox1.Text)
        TextBox2.Text = r
        Button1.Text = Len(s)
    End Sub
End Class
