Public Class Form1
    Private Sub mysub(ByVal aninteger As Integer, ByVal astring As String)
        Textbox1.Text = astring & " has an average 		of " & aninteger
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Call mysub(75, "John Doe")

        TextBox1.Text = ff_calc(10, 20)

    End Sub

    Function ff_calc(ByVal var1, ByVal var2) As Integer

        ff_calc = var1 + var2  ' return value

        Exit Function  ' early end to function
    End Function    ' end of function

End Class
