Public Class Form1

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        TextBox1.Text = CheckBox1.Checked
        TextBox2.Text = CheckBox1.CheckState
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        TextBox3.Text = RadioButton1.Checked
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Static a As Integer
        a += 1
        TextBox1.Text = "button clicked"

        Dim rtnval As Integer

        rtnval = MsgBox("this is the body of the message", vbYesNo, "title message")
        TextBox2.Text = rtnval ' returns 6 for yes and 7 for no

        TextBox3.Text = "length of tb2 is " & Len(TextBox1.Text)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' You should replace the bold image 
        ' in the sample below with an icon of your own choosing.
        PictureBox1.Image = Image.FromFile _
        (System.Environment.GetFolderPath _
        (System.Environment.SpecialFolder.Personal) _
        & "\Image.gif")
    End Sub

    Private Sub TextBox1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.GotFocus
        TextBox1.SelectionStart = 2
        TextBox1.SelectionLength = 5
    End Sub
End Class
