/*
 * Box.java
 *
 * Created on October 20, 2007, 12:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class Explosive extends Box {
    public Explosive(int x, int y, Game applet) {
        super(x, y, applet);
        setHealth(75);
        setMaxHealth(75);
    }
    
    public void refreshImage() {
        Rectangle bounds = new Rectangle(0, 0, 18, 20);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(applet.getBackgroundColor());
        g.fill(bounds);
        
        g.setColor(Color.black);
        if (getHealth() < getMaxHealth())
            g.drawRect(0, 3, 17, 20);
        else
            g.drawRect(0, 0, 17, 20);
        
        g.setColor(new Color(130, 0, 0));
        g.fillRect(1, 1, 16, 19);
        
        g.setColor(Color.black);
        g.fillRect(4, 7, 9, 10);
        g.setColor(Color.lightGray);
        g.drawLine(5, 14, 11, 12);
        g.drawLine(5, 12, 11, 14);
        g.drawRect(7, 9, 2, 2);
        
        if (getHealth() < getMaxHealth()) {
            for (int i = 0; i < 15; i++) {
                int rnd = (int)(Math.random() * 155) + 100;
                g.setColor(new Color(rnd, rnd, 0));
                g.fillRect((int)(Math.random()*bounds.width),
                        (int)(Math.random()*5), 2, 2);
            }
            
            for (int i = 0; i < 10; i++) {
                int rnd = (int)(Math.random() * 155) + 100;
                g.setColor(new Color(rnd, 0, 0));
                
                g.fillRect((int)(Math.random()*bounds.width),
                        (int)(Math.random()*5), 2, 2);
            }
        }
    }
    
    @Override public void draw(Graphics g) {
        if (getHealth() < getMaxHealth())
            refreshImage();
        super.draw(g);
    }
    
    public boolean makesExplosion() {
        return true;
    }
    
    public double getDamage() {
        return 70;
    }
}
