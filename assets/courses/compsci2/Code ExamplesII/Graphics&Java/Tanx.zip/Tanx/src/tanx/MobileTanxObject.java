/*
 * MobileTanxObject.java
 *
 * Created on October 19, 2007, 11:39 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

/**
 *
 * @author zacharylangley
 */
public abstract class MobileTanxObject extends TanxObject {
    private double speed;
    protected final double defaultSpeed;
    
    public MobileTanxObject(int x, int y, int health, Direction direction, double speed, Game applet) {
        super(x, y, health, direction, applet);
        defaultSpeed = this.speed = speed;
    }
    
    public void move() {        
        switch (getDirection()) {
            case NORTH:
                y -= speed;
                break;
            case EAST:
                x += speed;
                break;
            case SOUTH:
                y += speed;
                break;
            case WEST:
                x -= speed;
                break;
        }
    }
    
    public double getSpeed() { return speed; }
    
    public void setSpeed(double speed) { this.speed = speed; }
}
