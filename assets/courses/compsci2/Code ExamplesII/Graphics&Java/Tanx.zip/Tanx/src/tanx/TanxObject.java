package tanx;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public abstract class TanxObject {
    private double health;
    private double maxHealth;
    private Direction direction;
    protected double x;
    protected double y;
    protected BufferedImage image;
    protected Game applet;
    
    public TanxObject(int x, int y, int health, Direction direction, Game applet) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.maxHealth = this.health = health;
        this.applet = applet;
    }
    
    public void draw(Graphics g) {
        if (image == null)
            refreshImage();
        
        makeTransparent(image, applet.getBackgroundColor());
        g.drawImage(image, getX(), getY(), applet);
    }
    
    public boolean intersects(TanxObject to) {
        return getBounds().intersects(to.getBounds());
    }
    
    public Dimension offset() {
        return new Dimension((20 - getWidth()) / 2, (20 - getHeight()) / 2);
    }
    
    public void dealDamage(double damage, Direction fromDirection) {
        if (health <= 0)
            return;
        
        this.health -= damage;
        if (health <= 0)
            applet.explode(this, makesExplosion(), fromDirection);
    }
    
    protected Rectangle rotate90(Rectangle rect) {
        return new Rectangle(rect.y, rect.x, rect.height, rect.width);
    }
    
    private void makeTransparent(BufferedImage bImage, Color color) {
        int markColor = color.getRGB() | 0xFF000000;
        for (int y = 0; y < bImage.getHeight(); y++) {
            for (int x = 0; x < bImage.getWidth(); x++) {
                int col = bImage.getRGB(x,y);
                if (( col | 0xFF000000 ) == markColor) {
                    bImage.setRGB(x,y, 0x00FFFFFF & col);
                }
            }
        }
    }
    
    public abstract void refreshImage();
    public abstract void collisionBy(TanxObject to);
    public abstract boolean makesExplosion();
    
    public Rectangle getBounds() { return new Rectangle(getX(), getY(), getWidth(), getHeight()); }
    public Direction getDirection() { return direction; }
    public double getHealth() { return health; }
    public int getHeight() {
        if (image == null)
            refreshImage();
        
        return image.getHeight(applet);
    }
    public Image getImage() { return image; }
    public double getMaxHealth() { return maxHealth; }
    public int getWidth() {
        if (image == null)
            refreshImage();
        
        return image.getWidth(applet);
    }
    public int getX() { return (int)x; }
    public int getY() { return (int)y; }
    
    public void setDirection(Direction direction) {
        if (this.direction == direction)
            return;
        
        this.direction = direction;
        refreshImage();
    }
    public void setHealth(double health) { this.health = health; }
    public void setLocation(int x, int y) { this.x = x; this.y = y; }
    public void setMaxHealth(double health) { this.maxHealth = maxHealth; }
}
