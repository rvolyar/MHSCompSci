package tanx;

import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import javax.swing.JApplet;

public class Game extends JApplet {
    private enum GameCommand { NONE, REFRESH, NEXT_LEVEL, PREVIOUS_LEVEL };
    
    private GameCommand command = GameCommand.NONE;
    private Tank playerTank;
    private final LinkedList<TanxObject> tanxList = new LinkedList<TanxObject>();
    private final LinkedList<TanxPixel> pixelList = new LinkedList<TanxPixel>();
    public final LinkedList<TanxObject> toRemove = new LinkedList<TanxObject>();
    public final LinkedList<TanxObject> toAdd = new LinkedList<TanxObject>();
    private Rectangle bounds = new Rectangle(25, 25, 300, 300);
    private Color backgroundColor = Color.GRAY;
    private TanxObject[][] levelGrid = new TanxObject[15][15];
    private boolean playerExploding = false;
    private int level = 1;
    private KeyHandler keyHandler = new KeyHandler();
    private Image bufferImage;
    public AudioClip shotSound, teleportClip;
    private AudioClip explosionClip, explosionClip2;
    private boolean gameRunning = false;
    
    public void init() {
        setSize(350, 375);
        
        bufferImage = createImage(getWidth(), getHeight());
        
        shotSound = getAudioClip(getDocumentBase(), "MachineGun.wav");
        explosionClip = getAudioClip(getDocumentBase(), "ExplBass.wav");
        explosionClip2 = getAudioClip(getDocumentBase(), "ExplTreb.wav");
        teleportClip = getAudioClip(getDocumentBase(), "Teleport.wav");
        
        setIgnoreRepaint(true);
        requestFocus();
        
        addKeyListener(keyHandler);
        
        initLevel(level);
        
        new Thread(new Runnable() {
            public void run() {
                long lastLoopTime = System.currentTimeMillis();
                
                while (true) {
                    if (!gameRunning)
                        continue;
                    
                    long delta = System.currentTimeMillis() - lastLoopTime;
                    lastLoopTime = System.currentTimeMillis();
                    
                    if (command == GameCommand.REFRESH)
                        initLevel(level);
                    else if (command == GameCommand.NEXT_LEVEL)
                        initLevel(level + 1);
                    else if (command == GameCommand.PREVIOUS_LEVEL)
                        initLevel(level - 1);
                    command = GameCommand.NONE;
                    
                    Graphics2D g = (Graphics2D)bufferImage.getGraphics();
                    
                    g.setColor(Color.DARK_GRAY);
                    g.fill(getBounds());
                    
                    g.setColor(backgroundColor);
                    g.fill(bounds);
                    
                    handleKeyPresses();
                    
                    tanxList.addAll(toAdd);
                    toAdd.clear();
                    
                    /* Move the MobileTanxObjects. */
                    for (TanxObject curObj : tanxList) {
                        if (!(curObj instanceof MobileTanxObject))
                            continue;
                        
                        /*
                         * Save the old location and move the object.  We save
                         * the old location in case we move off the board with
                         * a tank, in which case we would reset it's coordinates.
                         */
                        Point p = new Point(curObj.getX(), curObj.getY());
                        ((MobileTanxObject)curObj).move();
                        
                        Rectangle union = bounds.union(curObj.getBounds());
                        if (!union.equals(bounds)) {
                            if (curObj instanceof Projectile) {
                                explode(curObj, false, null);
                                continue;
                            } else if (curObj instanceof Tank) {
                                switch (curObj.getDirection()) {
                                    case NORTH:
                                        curObj.setLocation(p.x, bounds.y);
                                        break;
                                    case EAST:
                                        curObj.setLocation(bounds.x + bounds.width - curObj.getWidth(), p.y);
                                        break;
                                    case SOUTH:
                                        curObj.setLocation(p.x, bounds.y + bounds.height - curObj.getHeight());
                                        break;
                                    case WEST:
                                        curObj.setLocation(bounds.x, p.y);
                                        break;
                                }
                            }
                        }
                        
                        for (TanxObject otherObj : tanxList) {
                            if (otherObj == curObj)
                                continue;
                            
                            boolean twoComputerTanks = (otherObj instanceof Tank) && (curObj instanceof Tank) &&
                                    (curObj != playerTank) && (otherObj != playerTank);
                            
                            if ((otherObj instanceof Box || otherObj instanceof Wall || twoComputerTanks) &&
                                    curObj.intersects(otherObj) && curObj instanceof Tank) {
                                switch (curObj.getDirection()) {
                                    case NORTH:
                                        curObj.setLocation(p.x, otherObj.getY() + otherObj.getHeight());
                                        break;
                                    case EAST:
                                        curObj.setLocation(otherObj.getX() - curObj.getWidth(), p.y);
                                        break;
                                    case SOUTH:
                                        curObj.setLocation(p.x, otherObj.getY() - curObj.getHeight());
                                        break;
                                    case WEST:
                                        curObj.setLocation(otherObj.getX() + otherObj.getWidth(), p.y);
                                        break;
                                }
                            }
                        }
                    }
                    
                    /* AI. */
                    for (TanxObject curObj : tanxList)
                        if (curObj instanceof Tank && ((Tank)curObj).isCPU())
                            doStuff((Tank)curObj);
                    
                    /* Handle intersections. */
                    for (TanxObject curObj : tanxList) {
                        for (TanxObject otherObj : tanxList) {
                            if (curObj == otherObj)
                                continue;
                            
                            if (curObj.intersects(otherObj))
                                curObj.collisionBy(otherObj);
                        }
                    }
                    
                    /* We may have removed some objects, let's update tanxList. */
                    tanxList.removeAll(toRemove);
                    toRemove.clear();
                    
                    /* Do some drawing. */
                    
                    /* Teleporters first. */
                    for (TanxObject curObj : tanxList)
                        if (curObj instanceof Teleporter || curObj instanceof LoadStation)
                            curObj.draw(g);
                    
                    /* Now everything else. */
                    for (TanxObject curObj : tanxList) {
                        if (!(curObj instanceof Teleporter || curObj instanceof LoadStation))
                            curObj.draw(g);
                        
                        if (curObj instanceof Wall) {
                            /* Outline the walls. */
                            int x = 0, y = 0;
                            
                            startLoop: for (y = 0; y < levelGrid.length; y++) {
                                for (x = 0; x < levelGrid[y].length; x++) {
                                    if (levelGrid[x][y] == curObj)
                                        break startLoop;
                                }
                            }
                            
                            int xLoc = curObj.getX(), yLoc = curObj.getY(),
                                    width = curObj.getWidth(), height = curObj.getHeight();
                            
                            /*
                             * All of the -1s are to insure that we do not fill anything at
                             * (x, 20) or (20, y). This will make Boxes line up with Walls
                             * correctly.
                             */
                            g.setColor(Color.BLACK);
                            if (x > 0 && !(levelGrid[x - 1][y] instanceof Wall))
                                g.drawLine(xLoc, yLoc, xLoc, yLoc + height - 1);
                            if (x < levelGrid.length - 1 && !(levelGrid[x + 1][y] instanceof Wall))
                                g.drawLine(xLoc + width - 1, yLoc, xLoc + width - 1, yLoc + height - 1);
                            if (y > 0 && !(levelGrid[x][y - 1] instanceof Wall))
                                g.drawLine(xLoc, yLoc, xLoc + width - 1, yLoc);
                            if (y < levelGrid[0].length - 1 && !(levelGrid[x][y + 1] instanceof Wall))
                                g.drawLine(xLoc, yLoc + height - 1, xLoc + width - 1, yLoc + height - 1);
                        }
                    }
                    
                    /* Border outlining. */
                    g.setColor(Color.BLACK);
                    for (int x = 0; x < levelGrid.length; x++) {
                        if (!(levelGrid[x][0] instanceof Wall))
                            g.drawLine((x * 20) + bounds.x, bounds.y, bounds.x + (x * 20) + 20, bounds.y);
                        if (!(levelGrid[x][levelGrid[x].length - 1] instanceof Wall))
                            g.drawLine((x * 20) + bounds.x, bounds.y + bounds.height,
                                    bounds.x + (x * 20) + 20, bounds.y + bounds.height);
                    }
                    
                    for (int y = 0; y < levelGrid.length; y++) {
                        if (!(levelGrid[0][y] instanceof Wall))
                            g.drawLine(bounds.x, (y * 20) + bounds.y, bounds.x, bounds.y + (y * 20) + 20);
                        if (!(levelGrid[levelGrid.length - 1][y] instanceof Wall))
                            g.drawLine(bounds.x + bounds.width, (y * 20) + bounds.y, bounds.x + bounds.width,
                                    bounds.y + (y * 20) + 20);
                    }
                    
                    /* Finally, draw the health bars and speed timers. */
                    for (TanxObject curObj : tanxList) {
                        if (curObj instanceof Tank) {
                            Tank theTank = (Tank)curObj;
                            int xCo = theTank.getX(), yCo = theTank.getY();
                            
                            if (theTank.getHealth() < theTank.getMaxHealth()) {
                                /* Let's draw the health bar. */
                                
                                g.setColor(Color.black);
                                g.fillRect(xCo, yCo - 4, theTank.getWidth(), 3);
                                g.setColor(Color.red);
                                g.fillRect(xCo, yCo - 3,
                                        (int)(theTank.getWidth() * theTank.getHealth() / theTank.getMaxHealth()), 1);
                            }
                            
                            if (theTank.getTimeLeft() > 0) {
                                String toDraw = String.valueOf(theTank.getTimeLeft());
                                
                                g.setFont(new Font("Serif", Font.BOLD, 11));
                                g.setColor(Color.WHITE);
                                g.drawString(toDraw, xCo, yCo + theTank.getHeight());
                            }
                        }
                    }
                    
                    /* Draw the explosions. */
                    for (Iterator<TanxPixel> it = pixelList.iterator(); it.hasNext(); ) {
                        TanxPixel p = it.next();
                        p.move();
                        p.draw(g);
                        
                        if (p.getAlpha() <= 0)
                            it.remove();
                    }
                    
                    String message = "Written by Zachary Langley.";
                    String message2 = "Game concept by Adam Jackman.";
                    g.setColor(Color.BLACK);
                    g.setFont(new Font("Arial", Font.PLAIN, 10));
                    
                    FontMetrics metrics = g.getFontMetrics();
                    g.drawString(message, (getWidth() - metrics.stringWidth(message)) / 2,
                            getHeight() - 2 * (metrics.getHeight() + 3));
                    g.drawString(message2, (getWidth() - metrics.stringWidth(message2)) / 2,
                            getHeight() - metrics.getHeight() - 3);
                    
                    /* Paint all our new image to the screen. */
                    getGraphics().drawImage(bufferImage, 0, 0, Game.this);
                    
                    if (!tanxList.contains(playerTank) && pixelList.size() == 0) {
                        initLevel(level);
                        continue;
                    }
                    
                    boolean found = false;
                    for (TanxObject curObj : tanxList) {
                        if (curObj instanceof Tank && curObj != playerTank) {
                            found = true;
                            break;
                        }
                    }
                    if (!found && pixelList.size() == 0)
                        initLevel(++level);
                    
                    try {
                        long time = lastLoopTime + 30 - System.currentTimeMillis();
                        Thread.sleep(Math.max(0, time));
                    } catch (Exception e) { }
                }
            }
        }).start();
    }
    
    public void start() {
        gameRunning = true;
    }
    
    public void stop() {
        gameRunning = false;
    }
    
    public Color getBackgroundColor() {
        return backgroundColor;
    }
    
    public void explode(TanxObject obj, boolean explosion, Direction direction) {
        PixelGrabber pg = new PixelGrabber(obj.getImage(), 0, 0, -1, -1, false);
        
        if (obj instanceof Tank && obj == playerTank)
            playerExploding = true;
        
        if (obj instanceof Explosive) {
            Point eCenter = new Point(obj.getX() + obj.getWidth() / 2,
                    obj.getY() + obj.getHeight() / 2);
            
            for (int i = 0; i < tanxList.size(); i++) {
                TanxObject t = tanxList.get(i);
                
                if (t == obj || t instanceof Projectile)
                    continue;
                
                Point tCenter = new Point(t.getX() + t.getWidth() / 2,
                        t.getY() + t.getHeight() / 2);
                
                if (Math.abs(tCenter.x - eCenter.x) < 35 && Math.abs(tCenter.y - eCenter.y) < 35)
                    t.dealDamage(((Explosive)obj).getDamage(), Direction.NONE);
            }
        }
        
        toRemove.add(obj);
        
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
            System.err.println("Interrupted waiting for pixels!");
            return;
        }
        
        if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
            System.err.println("Image fetch aborted or errored");
            return;
        }
        
        int[] pixels = (int[])pg.getPixels();
        int w = obj.getWidth(), h = obj.getHeight(), x = obj.getX(), y = obj.getY();
        
        Point center = new Point(x + w / 2, y + h / 2);
        for (int j = 0; j < h; j++) {
            if (j % 2 == 1 && j + 1 != h)
                continue;
            
            for (int i = 0; i < w; i++) {
                if (i % 2 == 1 && i + 1 != w)
                    continue;
                
                handlePixel(x+i, y+j, pixels[j * w + i], center);
            }
        }
        
        if (explosion) {
            int a = 6;
            for (int i = -a; i <= a; i++) {
                for (int j = -a; j <= a; j++) {
                    double rnd = Math.random() * 175 + 80;
                    
                    Color col;
                    if (Math.random() < .4)
                        col = new Color((int)rnd, (int)rnd, 0);
                    else if (Math.random() < .8)
                        col = new Color((int)rnd, (int)(rnd * .6), 0);
                    else
                        col = Color.black;
                    
                    double xSpeed = j * .1;
                    double ySpeed = i * .1;
                    
                    switch (direction) {
                        case NORTH:
                            if (i < 0)
                                ySpeed *= 3;
                            break;
                        case EAST:
                            if (j > 0)
                                xSpeed *= 3;
                            break;
                        case SOUTH:
                            if (i > 0)
                                ySpeed *= 3;
                            break;
                        case WEST:
                            if (j < 0)
                                xSpeed *= 3;
                            break;
                    }
                    
                    if (obj instanceof Explosive) {
                        xSpeed *= 3;
                        ySpeed *= 3;
                        
                        if (Math.random() < .5)
                            col = new Color((int)rnd, 0, 0);
                    }
                    
                    Point tpPoint = new Point(x + j + w/2 - 1, y + i + h/2 - 1);
                    
                    double distance = Math.sqrt(Math.pow(tpPoint.x - center.x, 2) + Math.pow(
                            tpPoint.y - center.y, 2));
                    
                    if (distance > a)
                        continue;
                    
                    TanxPixel tp = new TanxPixel(tpPoint.x, tpPoint.y,
                            xSpeed, ySpeed, (int)(Math.random() * 2) + 1, col);
                    tp.setExplosion(true);
                    pixelList.add(tp);
                }
            }
        }
    }
    
    public void handlePixel(int x, int y, int pixel, Point center) {
        int alpha = (pixel >> 24) & 0xff;
        int red   = (pixel >> 16) & 0xff;
        int green = (pixel >>  8) & 0xff;
        int blue  = (pixel      ) & 0xff;
        
        double xSpeed = (x - center.x) * .03;
        double ySpeed = (y - center.y) * .03;
        
        Color col = new Color(red, green, blue, alpha);
        
        if (col.equals(backgroundColor))
            return;
        
        TanxPixel tp = new TanxPixel(x, y, xSpeed, ySpeed, (int)(Math.random() * 2) + 1, col);
        pixelList.add(tp);
    }
    
    public void doStuff(Tank tank) {
        if (playerExploding)
            return;
        
        if (Math.random() > .99) {
            Projectile p = tank.fireProjectile();
            if (p != null)
                toAdd.add(p);
        } else if (Math.random() > .97) {
            tank.setDirection(randomDirection());
        }
    }
    
    public void initLevel(int level) {
        playerExploding = false;
        
        tanxList.clear();
        playerTank = null;
        
        this.level = level = Math.max(level, 1);
        
        try {
            Scanner scanner = new Scanner(new File("level" + level + ".txt"));
            
            
            for (int i = 0; i < 15; i++) {
                for (int j = 0; j < 15; j++) {
                    int x = j * 20 + bounds.x;
                    int y = i * 20 + bounds.y;
                    
                    String next = scanner.next();
                    
                    TanxObject toAdd = null;
                    
                    switch (next.charAt(0)) {
                        case 'E':
                            toAdd = new Explosive(x, y, this);
                            break;
                        case 'P':
                            toAdd = playerTank = new Tank(x, y, 150, randomDirection(), 2.85, false, this);
                            break;
                        case 'W':
                            toAdd = new Wall(x, y, this);
                            break;
                        case 'T':
                            toAdd = new Tank(x, y, randomDirection(), 2.85, true, this);                            break;
                        case 'B':
                            toAdd = new Box(x, y, this);
                            break;
                        case 'M':
                            toAdd = new Mine(x, y, this);
                            break;
                        case 'S':
                            toAdd = new SpeedUp(x, y, this);
                            break;
                    }
                    
                    for (int k = 1; k < next.length(); k++) {
                        switch (next.charAt(k)) {
                            case 'n':
                                toAdd.setDirection(Direction.NORTH);
                                break;
                            case 'e':
                                toAdd.setDirection(Direction.EAST);
                                break;
                            case 's':
                                toAdd.setDirection(Direction.SOUTH);
                                break;
                            case 'w':
                                toAdd.setDirection(Direction.WEST);
                                break;
                        }
                        if (next.charAt(k) >= '0' && next.charAt(k) <= '9') {
                            ((Tank)toAdd).setLevel(next.charAt(k) - '0');
                        }
                    }
                    
                    if (toAdd != null) {
                        toAdd.setLocation(x + toAdd.offset().width, y + toAdd.offset().height);
                        this.toAdd.add(toAdd);
                    }
                    levelGrid[j][i] = toAdd;
                }
            }
            
            /* Read the background color. */
            if (scanner.hasNext()) {
                String r = scanner.next(), g = scanner.next(), b = scanner.next();
                backgroundColor = new Color(Integer.parseInt(r), Integer.parseInt(g),
                        Integer.parseInt(b));
            } else {
                backgroundColor = Color.GRAY;
            }
            
            /*int x = 5 * 20 + bounds.x;
            int y = 4 * 20 + bounds.y;
             
            LoadStation loadStation = new LoadStation(x, y, this);
            loadStation.setLocation(x + loadStation.offset().width, y + loadStation.offset().height);
            this.toAdd.add(loadStation);
             
            x = 12 * 20 + bounds.x;
            y = 12 * 20 + bounds.y;
             
             
            Teleporter tele = new Teleporter(x, y, this);
            tele.setLoadStation(loadStation);
            tele.setLocation(x + tele.offset().width, y + tele.offset().height);
            this.toAdd.add(tele);
             */
            
            for (TanxObject t : toAdd)
                t.refreshImage();
            
        } catch (IOException e) {
            if (level == 1)
                return;
            initLevel(level - 1);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        
        if (playerTank == null) {
            System.err.println("player tank couldn't be found! error!");
            if (level == 1)
                return;
            initLevel(level - 1);
        }
    }
    
    private long lastKeyPressTime = 0;
    public void handleKeyPresses() {
        if (playerExploding)
            return;
        
        long delta = System.currentTimeMillis() - lastKeyPressTime;
        boolean handledKeyPress = false;
        
        if (keyHandler.isPressed(KeyEvent.VK_LEFT) && (handledKeyPress = true))
            playerTank.setDirection(Direction.WEST);
        if (keyHandler.isPressed(KeyEvent.VK_UP) && (handledKeyPress = true))
            playerTank.setDirection(Direction.NORTH);
        if (keyHandler.isPressed(KeyEvent.VK_DOWN) && (handledKeyPress = true))
            playerTank.setDirection(Direction.SOUTH);
        if (keyHandler.isPressed(KeyEvent.VK_RIGHT) && (handledKeyPress = true))
            playerTank.setDirection(Direction.EAST);
        if (keyHandler.isPressed(KeyEvent.VK_SPACE) && (handledKeyPress = true)) {
            Projectile p = playerTank.fireProjectile();
            if (p != null)
                toAdd.add(p);
        }
        if (keyHandler.isPressed(KeyEvent.VK_R) && delta > 200 && (handledKeyPress = true))
            command = GameCommand.REFRESH;
        if (keyHandler.isPressed(KeyEvent.VK_N) && delta > 200 && (handledKeyPress = true))
            command = GameCommand.NEXT_LEVEL;
        if (keyHandler.isPressed(KeyEvent.VK_P) && delta > 200 && (handledKeyPress = true))
            command = GameCommand.PREVIOUS_LEVEL;
        
        if (handledKeyPress)
            lastKeyPressTime = System.currentTimeMillis();
    }
    
    public Direction randomDirection() {
        return Direction.values()[(int)(Math.random() * 4)];
    }
}
