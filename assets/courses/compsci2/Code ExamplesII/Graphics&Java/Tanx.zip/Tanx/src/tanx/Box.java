/*
 * Box.java
 *
 * Created on October 20, 2007, 12:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class Box extends TanxObject {
    public Box(int x, int y, Game applet) {
        super(x, y, 60, Direction.NORTH, applet);
    }
    
    public void refreshImage() {
        int innerOffset = 3;
        Rectangle bounds = new Rectangle(0, 0, 20, 20);
        Rectangle innerBounds = new Rectangle(bounds.x + innerOffset, bounds.y + innerOffset,
                bounds.width - 2 * innerOffset, bounds.height - 2 * innerOffset);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(new Color(160, 100, 60));
        g.fill(bounds);
        
        g.setColor(new Color(100, 40, 0));
        g.fill(innerBounds);
        
        g.setColor(Color.BLACK);
        g.drawRect(0, 0, bounds.width - 1, bounds.height - 1);
        
        g.setColor(new Color(160, 100, 60));
        if (getHealth() == getMaxHealth()) {
            g.drawLine(1, 1, 18, 18);
        } else {
            Polygon breakPoly = new Polygon(new int[] {0, 7, 5, 9, 0}, new int[] {5, 7, 9, 12, 14}, 5);
            
            if (getDirection() == Direction.EAST || getDirection() == Direction.SOUTH) {
                for (int i = 0; i < breakPoly.npoints; i++) {
                    breakPoly.xpoints[i] = bounds.width - breakPoly.xpoints[i];
                    breakPoly.ypoints[i] = bounds.height - breakPoly.ypoints[i];
                }
            }
            
            if (getDirection() == Direction.NORTH || getDirection() == Direction.SOUTH) {
                for (int i = 0; i < breakPoly.npoints; i++) {
                    breakPoly.xpoints[i] ^= breakPoly.ypoints[i];
                    breakPoly.ypoints[i] ^= breakPoly.xpoints[i];
                    breakPoly.xpoints[i] ^= breakPoly.ypoints[i];
                }
            }
            
            g.drawLine(1, 1, 10, 9);
            g.drawLine(10, 9, 13, 7);
            g.drawLine(13, 7, 18, 18);
            
            Stroke oldStroke = g.getStroke();
            g.setStroke(new BasicStroke(1.5f));
            g.setColor(Color.black);
            g.draw(breakPoly);
            g.setStroke(oldStroke);
            
            g.setColor(applet.getBackgroundColor());
            g.fill(breakPoly);
        }
    }
    
    public void dealDamage(double damage, Direction dir) {
        super.dealDamage(damage, dir);
        refreshImage();
    }
    
    public void collisionBy(TanxObject to) {
        if (to instanceof Projectile) {
            dealDamage(((Projectile)to).getDamage(), to.getDirection().opposite());
            setDirection(to.getDirection().opposite());
        }
    }
    
    public boolean makesExplosion() {
        return false;
    }
}
