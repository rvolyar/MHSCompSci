/*
 * Teleporter.java
 *
 * Created on October 22, 2007, 10:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class LoadStation extends TanxObject {
    public LoadStation(int x, int y, Game applet) {
        super(x, y, 60, Direction.NORTH, applet);
    }
    
    public void refreshImage() {
        Rectangle bounds = new Rectangle(0, 0, 20, 20);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(applet.getBackgroundColor());
        g.fill(bounds);
        
        Polygon diamond = new Polygon(new int[] { 3, 10, 17, 10}, new int[] { 10, 3, 10, 17}, 4);
        g.setColor(Color.green);
        g.fill(diamond);
        g.setColor(Color.black);
        g.draw(diamond);
    }
    
    @Override public void dealDamage(double damage, Direction dir) { }
    
    public void collisionBy(TanxObject to) { }
    
    public boolean makesExplosion() {
        return false;
    }
}