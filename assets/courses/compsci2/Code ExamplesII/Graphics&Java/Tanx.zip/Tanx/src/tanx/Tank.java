package tanx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class Tank extends MobileTanxObject {
    private boolean isCPU;
    private long lastShot = 0;
    private long speedTimer = 0;
    private int level = 1;
    
    private static final Color[] cpuColors = {
        new Color(38, 81, 0),
        new Color(30, 50, 100),
    };
    
    private static final int[] healthLevels = {
        75,
        130,
    };
    
    public Tank(int x, int y, int health, Direction direction, double speed, boolean cpu, Game applet) {
        super(x, y, health, direction, speed, applet);
        this.isCPU = cpu;
    }
    
    public Tank(int x, int y, Direction direction, double speed, boolean cpu, Game applet) {
        this(x, y, healthLevels[0], direction, speed, cpu, applet);
    }
    
    public void refreshImage() {
        Rectangle track1 = new Rectangle(0, 0, 18, 4);
        Rectangle body = new Rectangle(2, track1.height, 13, 10);
        Rectangle track2 = new Rectangle(track1.x, body.y + body.height, track1.width, track1.height);
        Ellipse2D.Double bodyCircle = new Ellipse2D.Double((track1.width - body.height) / 2,
                body.y, body.height, body.height);
        Rectangle gunner = new Rectangle(0, track1.height + body.height / 2 - 1, track1.width / 2, 2);
        
        /*
         * Default gunner coordinates are set to face WEST (or NORTH after
         * rotating).
         */
        if (getDirection() == Direction.EAST || getDirection() == Direction.SOUTH)
            gunner.x += gunner.width;
        
        /*
         * Default coordinates are set for Tanks that are facing EAST or WEST,
         * so if this tank is facing NORTH or SOUTH, rotate the rectangles 90
         * degrees.
         */
        if (getDirection() == Direction.NORTH || getDirection() == Direction.SOUTH) {
            body = rotate90(body);
            track1 = rotate90(track1);
            track2 = rotate90(track2);
            gunner = rotate90(gunner);
            bodyCircle = new Ellipse2D.Double(bodyCircle.y, bodyCircle.x, bodyCircle.height, bodyCircle.width);
        }
        
        Rectangle union = body.union(track1).union(track2).union(gunner);
        image = new BufferedImage(union.width + 1, union.height + 1, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(applet.getBackgroundColor());
        g.fillRect(0, 0, image.getWidth(applet), image.getHeight(applet));
        
        g.setColor(isCPU ? Color.BLACK : Color.BLUE.darker().darker());
        g.fill(body);
        
        g.setColor(isCPU ? Color.DARK_GRAY : Color.BLUE);
        g.fill(bodyCircle);
        
        g.setColor(isCPU ? cpuColors[level - 1] : Color.RED);
        g.fill(track1);
        g.fill(track2);
        
        g.setColor(Color.black);
        g.draw(body);
        g.draw(track1);
        g.draw(track2);
        g.draw(bodyCircle);
        
        g.setColor(isCPU ? Color.DARK_GRAY : Color.BLUE);
        g.fill(gunner);
        g.setColor(Color.black);
        g.draw(gunner);
    }
    
    public Projectile fireProjectile() {
        if (System.currentTimeMillis() - lastShot < 500)
            return null;
        
        int x = getX(), y = getY();
        
        Projectile proj = new Projectile(x, y, getDirection(), level, applet);
        proj.setSpeed(proj.getSpeed() + getSpeed());
        
        switch (getDirection()) {
            case NORTH:
                x += (getWidth() - proj.getWidth()) / 2;
                y -= proj.getHeight() + 3;
                break;
            case EAST:
                x += getWidth() + 3;
                y += (getHeight() - proj.getHeight()) / 2;
                break;
            case SOUTH:
                x += (getWidth() - proj.getWidth()) / 2;
                y += getHeight() + 3;
                break;
            case WEST:
                x -= proj.getWidth() + 3;
                y += (getHeight() - proj.getHeight()) / 2;
                break;
        }
        
        proj.setLocation(x, y);
        
        lastShot = System.currentTimeMillis();
        
        return proj;
    }
    
    public void move() {
        if (System.currentTimeMillis() - speedTimer > 10000)
            setSpeed(defaultSpeed);
        
        super.move();
    }
    
    public boolean isCPU() { return isCPU; }
    
    public void collisionBy(TanxObject to) {
        if (to instanceof Tank) {
            if (!((Tank)to).isCPU || !isCPU)
                dealDamage(getHealth(), getDirection());
        } else if (to instanceof Projectile)
            dealDamage(((Projectile)to).getDamage(), to.getDirection());
        else if (to instanceof Mine)
            dealDamage(((Mine)to).getDamage(), getDirection().opposite());
        else if (to instanceof SpeedUp) {
            setSpeed(getSpeed() + .5);
            speedTimer = System.currentTimeMillis();
        }
    }
    
    public int getTimeLeft() {
        if (System.currentTimeMillis() - speedTimer > 10000)
            return 0;
        return 10 - (int)((System.currentTimeMillis() - speedTimer) / 1000);
    }
    
    public boolean makesExplosion() {
        return true;
    }
    
    public void setLevel(int level) {
        this.level = level;
        if (isCPU) {
            setMaxHealth(healthLevels[level - 1]);
            setHealth(healthLevels[level - 1]);
            refreshImage();
        }
    }
}