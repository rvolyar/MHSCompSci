/*
 * Box.java
 *
 * Created on October 20, 2007, 12:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class Wall extends TanxObject {
    public Wall(int x, int y, Game applet) {
        super(x, y, 50, Direction.NORTH, applet);
    }
    
    public void refreshImage() {
        Rectangle bounds = new Rectangle(0, 0, 20, 20);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();        
        
        g.setColor(Color.DARK_GRAY);
        g.fill(bounds);
    }
    
    @Override public void dealDamage(double damage, Direction dir) { }
    
    public void collisionBy(TanxObject to) { }
    
    public boolean makesExplosion() {
        return false;
    }
}
