/*
 * KeyHandler.java
 *
 * Created on October 22, 2007, 8:15 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.AWTEvent;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 *
 * @author zacharylangley
 */
public class KeyHandler extends KeyAdapter implements AWTEventListener {
    private boolean[] keys = new boolean[1024];
    
    public boolean isPressed(int key) {
        return keys[key];
    }
    
    public void keyPressed(KeyEvent e) {
        if (e.isConsumed())
            return;
        
        keys[e.getKeyCode()] = true;
    }
    
    public void keyReleased(KeyEvent e) {
        if (e.isConsumed())
            return;
        
        keys[e.getKeyCode()] = false;
    }
    
    public void eventDispatched(AWTEvent e) {
        if (e.getID() == KeyEvent.KEY_PRESSED)
            keyPressed((KeyEvent)e);
        if (e.getID() == KeyEvent.KEY_RELEASED)
            keyReleased((KeyEvent)e);
    }
    
}