/*
 * Box.java
 *
 * Created on October 20, 2007, 12:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class Mine extends TanxObject {
    private Color color = Color.RED;
    
    public Mine(int x, int y, Game applet) {
        super(x, y, 50, Direction.NORTH, applet);
        
        refreshImage();
    }
    
    public void refreshImage() {
        Rectangle bounds = new Rectangle(0, 0, 6, 6);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g.setColor(applet.getBackgroundColor());
        g.fill(bounds);

        g.setColor(Color.BLACK);
        g.drawOval(0, 0, bounds.width - 1, bounds.height - 1);
        g.setColor(color);
        g.fillOval(1, 1, bounds.width - 2, bounds.height - 2);
    }
    
    
    public void collisionBy(TanxObject to) {
        if (to instanceof Tank)
            dealDamage(getHealth(), Direction.NONE);
    }
    
    public boolean makesExplosion() {
        return true;
    }
    
    public double getDamage() {
        return 200;
    }
}
