/*
 * Teleporter.java
 *
 * Created on October 22, 2007, 10:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class Teleporter extends TanxObject {
    private LoadStation station;
    
    public Teleporter(int x, int y, Game applet) {
        super(x, y, 60, Direction.NORTH, applet);
    }
    
    public void refreshImage() {
        Rectangle bounds = new Rectangle(0, 0, 20, 20);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(applet.getBackgroundColor());
        g.fill(bounds);
        
        g.setColor(Color.darkGray);
        g.fillOval(0,0,20,20);
        g.setColor(Color.black);
        g.drawOval(0,0,19,19);
        g.drawOval(3,3,14,14);
        
        g.setColor(applet.getBackgroundColor());
        g.fillOval(4,4,12,12);
        g.setColor(Color.green);
        int rnd1 = (int)(Math.random()*8)-4;
        int rnd2 = (int)(Math.random()*8)-4;
        int rnd3 = (int)(Math.random()*8)-4;
        int rnd4 = (int)(Math.random()*8)-4;
        
        g.drawLine(4, 10, 10 + rnd3, 10 + rnd1);
        g.drawLine(16, 10, 10 + rnd3, 10 + rnd1);
        g.drawLine(4, 10, 10 + rnd4, 10 + rnd2);
        g.drawLine(16, 10, 10 + rnd4, 10 + rnd2);
    }
    
    @Override public void dealDamage(double damage, Direction dir) { }
    
    public void collisionBy(TanxObject to) {
        if (station != null) {
            to.setLocation(station.getX() - (to.getWidth() - getWidth()) / 2,
                    station.getY() - (to.getHeight() - getHeight()) / 2);
        }
    }
    
    public boolean makesExplosion() {
        return false;
    }
    
    public void setLoadStation(LoadStation ls) {
        station = ls;
    }
    
    @Override public void draw(Graphics g) {
        refreshImage();
        super.draw(g);
    }
    
    @Override public boolean intersects(TanxObject to) {
        Rectangle thisBounds = new Rectangle(getX(), getY(), getWidth(), getHeight());
        Rectangle otherBounds = new Rectangle(to.getX(), to.getY(),
                to.getWidth(), to.getHeight());
        Rectangle union = thisBounds.union(otherBounds);
        
        return (union.getWidth() * union.getHeight()) * .7 < (getWidth() * getHeight());
    }
}