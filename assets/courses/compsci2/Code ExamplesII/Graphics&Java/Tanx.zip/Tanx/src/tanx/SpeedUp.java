/*
 * Box.java
 *
 * Created on October 20, 2007, 12:05 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 *
 * @author zacharylangley
 */
public class SpeedUp extends TanxObject {
    public SpeedUp(int x, int y, Game applet) {
        super(x, y, 50, Direction.NORTH, applet);
    }
    
    public void refreshImage() {
        Rectangle bounds = new Rectangle(0, 0, 20, 20);
        
        image = new BufferedImage(bounds.width, bounds.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(Color.black);
        g.drawRect(0, 0, bounds.width - 1, bounds.height - 1);
        
        g.setColor(Color.blue);
        g.fill3DRect(2, 2, 17, 17, true);
        
        g.setColor(Color.yellow);
        for (int t=4;t<=13;t+=4) {
            g.drawLine(t, 6, t+4, 10);
            g.drawLine(t+4, 10, t, 14);
        }
        for (int t=5;t<=13;t+=4) {
            g.drawLine(t, 6, t+4, 10);
            g.drawLine(t+4, 10, t, 14);
        }
    }
    
    @Override public void dealDamage(double damage, Direction dir) { }
    
    public void collisionBy(TanxObject to) {
        if (to instanceof Tank)
            applet.toRemove.add(this);
    }
    
    public boolean makesExplosion() {
        return false;
    }
}
