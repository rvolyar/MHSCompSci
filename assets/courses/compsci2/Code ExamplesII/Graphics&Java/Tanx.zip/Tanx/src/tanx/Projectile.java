package tanx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Projectile extends MobileTanxObject {
    private int gunLevel;
    
    public Projectile(int x, int y, Direction direction, int level, Game applet) {
        super(x, y, 1, direction, 2.5, applet);
        this.gunLevel = level;
    }
    
    public void refreshImage() {
        Rectangle overLaser = new Rectangle(2, 0, 6, 4);
        Rectangle laser = new Rectangle(0, 1, 10, 2);
        
        Rectangle union = overLaser.union(laser);
        
        Rectangle overLaser2 = new Rectangle(2, union.height + 1, 6, 4);
        Rectangle laser2 = new Rectangle(0, union.height + 2, 10, 2);
        
        /*
         * Default coordinates are set for Tanks that are facing EAST or WEST,
         * so if this tank is facing NORTH or SOUTH, rotate the rectangles 90
         * degrees.
         */
        if (getDirection() == Direction.NORTH || getDirection() == Direction.SOUTH) {
            overLaser = rotate90(overLaser);
            laser = rotate90(laser);
            overLaser2 = rotate90(overLaser2);
            laser2 = rotate90(laser2);
        }
        
        union = overLaser.union(laser);
        if (gunLevel > 1)
            union = union.union(overLaser2).union(laser2);
        
        image = new BufferedImage(union.width, union.height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g = (Graphics2D)image.getGraphics();
        g.setColor(applet.getBackgroundColor());
        g.fill(union);
        
        Color color = (gunLevel <= 2 ? Color.YELLOW : Color.RED.darker());
        
        g.setColor(color.darker());
        g.fill(overLaser);
        
        g.setColor(color);
        g.fill(laser);
        
        if (gunLevel > 1) {
            g.setColor(color.darker());
            g.fill(overLaser2);
            
            g.setColor(color);
            g.fill(laser2);
        }
    }
    
    public double getDamage() {
        return 50 * gunLevel;
    }
    
    public void collisionBy(TanxObject to) {
        if (to instanceof Mine || to instanceof SpeedUp || to instanceof Teleporter || to instanceof LoadStation)
            return;
        if (to instanceof Projectile) {
            if (((Projectile)to).gunLevel <= 0)
                return;
            
            if (gunLevel <= ((Projectile)to).gunLevel)
                dealDamage(getHealth(), to.getDirection());
            if (gunLevel >= ((Projectile)to).gunLevel)
                to.dealDamage(to.getHealth(), getDirection());

            int oldLevel = ((Projectile)to).gunLevel;
            ((Projectile)to).gunLevel -= gunLevel;
            gunLevel -= oldLevel;
            
            refreshImage();
            to.refreshImage();
        } else
            dealDamage(getHealth(), to.getDirection());
    }
    
    public boolean makesExplosion() {
        return false;
    }
}
