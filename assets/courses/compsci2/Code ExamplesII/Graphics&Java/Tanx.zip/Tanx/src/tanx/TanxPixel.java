/*
 * TanxPixel.java
 *
 * Created on October 18, 2007, 9:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tanx;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/**
 *
 * @author zacharylangley
 */
public class TanxPixel {
    private Color color;
    private double xSpeed;
    private double ySpeed;
    private double x;
    private double y;
    public final long timeCreated;
    private int size;
    private boolean explosion = false;
    private float alpha = 1.0f;
    
    public TanxPixel(int x, int y, double xSpeed, double ySpeed, int size, Color color) {
        this.x = x;
        this.y = y;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.color = color;
        timeCreated = System.currentTimeMillis();
        this.size = size;
    }
    
    public void move() {
        x += xSpeed;
        y += ySpeed;
        
        x += (Math.random() - .5) * .9;
        y += (Math.random() - .5) * .9;
    }
    
    public void draw(Graphics g1) {
        if (alpha <= 0)
            return;
        
        Graphics2D g = (Graphics2D)g1;
        
        Composite oldComposite = g.getComposite();        
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
        alpha -= 0.03;
        
        g.setColor(color);
        g.fillRect(getX(), getY(), size, size);
        
        g.setComposite(oldComposite);
    }
    
    public void setExplosion(boolean b) { this.explosion = b; }
    public void setXSpeed(double xSpeed) { this.xSpeed = xSpeed; }
    public void setYSpeed(double ySpeed) { this.ySpeed = ySpeed; }

    public float getAlpha() { return alpha; }
    public boolean getExplosion() { return explosion; }
    public int getX() { return (int)x; }
    public int getY() { return (int)y; }
}
