/*
 * Sprite.java
 *
 * Created on November 7, 2007
 */

package stealth;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Rectangle2D;

/**
 * @version 1.0
 * @author Zachary Langley
 */
public class Sprite {
    private double x;
    private double y;
    private int width;
    private int height;
    private double xSpeed;
    private double ySpeed;
    
    /**
     * <code>Sprite</code> constructor.
     *
     * @param x      the x coordinate to draw the <code>Sprite</code> at.
     * @param y      the y coordinate to draw the <code>Sprite</code> at.
     * @param width  the width of the <code>Sprite</code>.
     * @param height the height of the <code>Sprite</code>.
     */
    public Sprite(int x, int y, int width, int height) {
        this.x = x;
        this.y = x;
        this.width = width;
        this.height = height;
    }
    
    /**
     * Adds the <code>xSpeed</code> to the <code>x</code> variable and the
     * <code>ySpeed</code> to the <code>y</code> variable.
     */
    public void move() {
        x += xSpeed;
        y += ySpeed;
    }
    
    /**
     * Paints the <code>Sprite</code> specified by its x, y, width, and height.
     *
     * @param g the graphics context to draw the <code>Sprite</code> on.
     */
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.blue);
        g2d.fill(getArc());
    }
    
    /**
     * @return the bounds of the <code>Sprite</code>.
     */
    public Rectangle2D.Double getBounds() {
        return new Rectangle2D.Double(x, y, width, height);
    }

    /**
     * @param sprite the <code>Sprite</code> to compare against.
     * @return true if this <code>Sprite</code> intersects with the <code>Sprite</code> passed in.
     */
    public boolean collidingWith(Sprite sprite) {
        Sprite above, below;
        
        if (getY() + getHeight() < sprite.getY() + sprite.getHeight()) {
            above = this;
            below = sprite;
        } else {
            above = sprite;
            below = this;
        }
        
        return (below.getArc().contains(new Point(above.getX(), above.getY() + above.getHeight()))) ||
                (below.getArc().contains(new Point(above.getX() + above.getWidth(), above.getY() + above.getHeight())) ||
                above.getArc().contains(new Point(below.getX() + below.getWidth() / 2, below.getY())));
    }
    
    /**
     * Changes the speed.
     */
    public void collidedWith(Sprite sprite) {
        xSpeed = (center().x - sprite.center().x) / 2;
        ySpeed = (center().y - sprite.center().y) / 2;
    }
    
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getX() { return (int)x; }
    public int getY() { return (int)y; }
    public double getHorizontalSpeed() { return xSpeed; }
    public double getVerticalSpeed() { return ySpeed; }

    public void setLocation(Point p) {
        setX(p.x);
        setY(p.y);
    }

    public void setWidth(int width) { this.width = width; }
    public void setHeight(int height) { this.height = height; }
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    public void setHorizontalSpeed(double speed) { xSpeed = speed; }
    public void setVerticalSpeed(double speed) { ySpeed = speed; }
    
    private Arc2D.Double getArc() {
        return new Arc2D.Double(x, y, width, height * 2, 0, 180, Arc2D.PIE);
    }

    private Point center() {
        return new Point((int)x + width / 2, (int)y + height / 2);
    }
}