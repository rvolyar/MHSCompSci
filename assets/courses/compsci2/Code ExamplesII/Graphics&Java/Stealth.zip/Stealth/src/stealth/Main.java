/*
 * Main.java
 *
 * Created on November 7, 2007
 */

package stealth;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JApplet;

/**
 * @version 1.0
 * @author Zachary Langley
 */
public class Main extends JApplet {
    private Image bufferImage;
    private Sprite playerSprite = new Sprite(20, 20, 50, 25);
    private Sprite computerSprite = new Sprite(100, 100, 100, 50);
    private boolean playerVisible = true;
    
    public void init() {
        setSize(500, 500);
        
        bufferImage = createImage(getWidth(), getHeight());
        
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                playerSprite.setLocation(new Point(e.getX() - playerSprite.getWidth() / 2,
                        e.getY() - playerSprite.getHeight() / 2));
            }
        });
        
        addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                playerVisible = !playerVisible;
            }
        });
        
        new StealthThread().start();
    }
    
    private class StealthThread extends Thread {
        public void run() {
            while (true) {
                Graphics2D g = (Graphics2D)bufferImage.getGraphics();
                
                g.setColor(Color.white);
                g.fill(getBounds());
                
                if (playerVisible)
                    playerSprite.draw(g);
                computerSprite.draw(g);
                
                computerSprite.move();
                doLogic();
                
                getGraphics().drawImage(bufferImage, 0, 0, Main.this);
                
                try {
                    Thread.sleep(10);
                } catch (Exception e) { }
            }
        }
    }
    
    private void doLogic() {
        if (playerVisible && playerSprite.collidingWith(computerSprite))
            computerSprite.collidedWith(playerSprite);
        
        if (computerSprite.getX() <= 0 || computerSprite.getX() + computerSprite.getWidth() >= getWidth())
            computerSprite.setHorizontalSpeed(-computerSprite.getHorizontalSpeed());
        if (computerSprite.getY() <= 0 || computerSprite.getY() + computerSprite.getHeight() >= getWidth())
            computerSprite.setVerticalSpeed(-computerSprite.getVerticalSpeed());
        
        computerSprite.setX(Math.min(computerSprite.getX(), getWidth() - computerSprite.getWidth()));
        computerSprite.setX(Math.max(computerSprite.getX(), 0));
        computerSprite.setY(Math.min(computerSprite.getY(), getHeight() - computerSprite.getHeight()));
        computerSprite.setY(Math.max(computerSprite.getY(), 0));
        
        final double delta = .3;
        if (computerSprite.getHorizontalSpeed() > 0)
            computerSprite.setHorizontalSpeed(Math.max(computerSprite.getHorizontalSpeed() - delta, 0));
        if (computerSprite.getHorizontalSpeed() < 0)
            computerSprite.setHorizontalSpeed(Math.min(computerSprite.getHorizontalSpeed() + delta, 0));
        
        if (computerSprite.getVerticalSpeed() > 0)
            computerSprite.setVerticalSpeed(Math.max(computerSprite.getVerticalSpeed() - delta, 0));
        if (computerSprite.getVerticalSpeed() < 0)
            computerSprite.setVerticalSpeed(Math.min(computerSprite.getVerticalSpeed() + delta, 0));
    }
}