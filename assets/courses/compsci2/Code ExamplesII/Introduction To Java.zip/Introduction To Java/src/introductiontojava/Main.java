/*
 * Main.java
 *
 * Created on August 16, 2006, 11:42 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package introductiontojava;
import javax.swing.JOptionPane;

/**
 *
 * @author Dave
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        String names[] = new String[5];
		
		// ask for names
		for(int x=0;x< 5;x++)
		{
			//names[x] = new String;
			names[x] = JOptionPane.showInputDialog("What is your name? ");
		}
		System.out.println("Your Names Are:");
		for(int x=0;x< 5;x++)
		{
			//names[x] = new String;
			
			System.out.println(names[x]); 
		}
    }
    
}
