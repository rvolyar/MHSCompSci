/*
 * HW2.java
 *
 * Created on August 16, 2006, 12:15 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Dave
 */
//import javax.swing.Japplet;
import java.awt.Graphics;
//import java.applet.Applet;

public class HW2 extends javax.swing.JApplet 
{
    
    ///** Creates a new instance of HW2 */
    public HW2() 
    {
   
    }
     public void paint(Graphics g)
      	   {
	     g.drawLine(15, 10, 210, 10);  // 15, 10 is x,y of start of line
				           // 210, 10 is x,y of end of line
	     g.drawLine(15, 30, 210, 30);
	  // pixel coordinate
             g.drawString("hello World",25, 25);
	   }
    
}
