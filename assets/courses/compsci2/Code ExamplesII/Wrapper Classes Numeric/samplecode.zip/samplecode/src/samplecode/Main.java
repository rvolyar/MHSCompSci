/*
 * Main.java
 *
 * Created on August 21, 2006, 6:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package samplecode;

/**
 *
 * @author Dave
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        
		// this code wont even compile
		/*int a[] = new int[20];
	
		a[0] = 10;
		a[1] = 4.5;
		a[2] = (long)4;   */
		
		//double d = 23.3;
		//int a = d;
		
		// create an array of number class so it actually may contain 
		// heterogeneous elements, like Int, double, etc... all derrived classes of Number
		Number[] nums = new Number[3]; //initial state is NULL
		Integer i = new Integer(34);
		Double d = new Double (45.55);
		Float f = new Float(3.14159);
		
		nums[0] = i;
		nums[1] = d;
		nums[2] = f;
		
		System.out.println(nums[0].toString() + " " + nums[2].toString());
		System.out.println(nums[1].intValue() + " " + nums[2].intValue());
		
		
		String s = new String("21.77");
		Number myNum; 
		myNum = Double.valueOf(s);             
		System.out.println(myNum.intValue());
		
                for(Number x : nums)
                {
                  System.out.println(x.toString());   
                
               }

		
		// attempt to create instance of abstract Number class
		// ERROR abstract class can not be instantiated
		
		//Number n = new Number();
    }
    
}
