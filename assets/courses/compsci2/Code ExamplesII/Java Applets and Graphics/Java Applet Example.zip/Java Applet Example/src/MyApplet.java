/*
 * MyApplet.java
 *
 * Created on August 21, 2006, 8:12 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author Dave
 */
public class MyApplet extends java.applet.Applet  implements ActionListener, KeyListener
{
    
      // add a button
        Button b = new Button();
        
     // add a label
        Label l = new Label();
        
    
    /** Initialization method that will be called after the applet is loaded
     *  into the browser.
     */
    public void init() 
    {
        setSize(500,500);  // enlarge the form
        
        // set its attributes
        b.setVisible(true);
        b.setLabel("BUTTON");
        b.setLocation(100,100);
        b.setSize(new java.awt.Dimension(40,60));
        
        // add the button to the applet
        add(b);
        
        // associate the button with A USER ACTION
        b.addActionListener(this);
        
        // associate the button with KEY EVENTS
        b.addKeyListener(this);
        
        // Set Labels Attributes
        
        l.setVisible(true);
        l.setLocation(new java.awt.Point(100,100));
        l.setText("");
        
        // add the label to the applet
        add(l);
        
        
        // add ability to execute a behavior when the button is clicked
    }
    public void paint(Graphics g)
    {
     g.drawString("Hello World", 50, 25);   
     
     // put anything that constantly needs to be reset here
      b.setLocation(100,100);
      b.setSize(80,80);
      l.setSize(new java.awt.Dimension(200,100));
     }
   
    
    // WE NOW need to handle the events that occur when the user does something
    public void actionPerformed(ActionEvent a)
    {
     Button c = ((Button)a.getSource());
     
     if (c.equals(b))
     {
      l.setText("BUTTON CLICKED");   
     }
     
     repaint();
         
    }
    
    public void keyPressed(KeyEvent k)
    {
        
        l.setText(k.getKeyText(k.getKeyCode()));
    }
    
    public void keyTyped(KeyEvent k)
    {
    }
    
    public void keyReleased(KeyEvent k)
    {
    }
    }

