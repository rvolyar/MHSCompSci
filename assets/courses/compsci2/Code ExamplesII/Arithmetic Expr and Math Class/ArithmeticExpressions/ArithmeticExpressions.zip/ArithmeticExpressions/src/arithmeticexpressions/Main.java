/*
 * Main.java
 *
 * Created on August 19, 2006, 9:59 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package arithmeticexpressions;
/*  OUTPUT FOR ARITHMETIC OPERATIONS:
 
	INTEGER MATH a = 25 b = 10 c = 20 d = 30 e = 0
	25
	31
	1500
	0
	25
	DOUBLE MATH a = 25.0 b = 10.0 c = 20.0 d = 30.0 e = .0
	40.0
	31.75
	1500.0
	0.058333333333333334
	25.0

 
 
 */

import javax.swing.JOptionPane;
import java.lang.Math;

public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // LOCAL Primitave Double
		double yourGrade = 0.0;
		
		// create instance of the CalcIt class
		// LOCAL variable
		CalcIt myCalc = new CalcIt();
		
		//another way to display the results
		yourGrade = myCalc.calcAvg();	
		JOptionPane.showMessageDialog(null, "Your Average Grade is: "
			 + yourGrade , "RESULTS", JOptionPane.PLAIN_MESSAGE);
			 
		// TEST ARITHMETIC EXPRESSIONS
		System.out.println("INTEGER MATH a = 25 b = 10 c = 20 d = 30 e = 0");
		myCalc.modInts(25, 10, 20, 30);
		
		System.out.println("DOUBLE MATH a = 25.0 b = 10.0 c = 20.0 d = 30.0 e = .0");
		myCalc.modDoubles(25.0, 10.0, 20.0, 30.0 );
		
		
		// USE MATH CLASS
		myCalc.useMath();
		
		int x = 10 * 6 % 9 + 5 / 3 -2;
		System.out.println("num 8 is " + x);
		
		System.exit(0);
	}
    
}
