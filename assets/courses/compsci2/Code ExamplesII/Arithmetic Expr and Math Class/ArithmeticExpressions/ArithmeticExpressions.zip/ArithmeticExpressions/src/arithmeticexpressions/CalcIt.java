/*
 * CalcIt.java
 *
 * Created on August 19, 2006, 10:02 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package arithmeticexpressions;

import javax.swing.JOptionPane;
import java.lang.Math;
/**
 *
 * @author Dave
 */

    // NEW CLASS USED TO CALCULAE THE AVERAGE GRADE
	public class CalcIt
	{
		// variables available only to class "CalcIt"
		private final int numGrades;
		private double grade1;
		private double grade2;
		private double grade3;
		private double grade4;
		private double grade5;

	// class constructor called when an Instance of a class
	// is created
		public CalcIt()
		{
			// set the initial values of the grades
			numGrades = 5;
			grade1 = 0.0;
			grade2 = 0.0;
			grade3 = 0.0;
			grade4 = 0.0;
			grade5 = 0.0;
		}
	
	// public method of the class "CalcIt"
		public double calcAvg()
		{
			double avg = 0.0;
			String input;
			
			input = JOptionPane.showInputDialog("Enter First Grade: ");
			grade1 = Integer.parseInt(input);
								
			input = JOptionPane.showInputDialog("Enter Second Grade: ");
			grade2 = Integer.parseInt(input);
			
			input = JOptionPane.showInputDialog("Enter Third Grade: ");
			grade3 = Integer.parseInt(input);
			
			input = JOptionPane.showInputDialog("Enter Fourth Grade: ");
			grade4 = Integer.parseInt(input);
			
			input = JOptionPane.showInputDialog("Enter Fifth Grade: ");
			grade5 = Integer.parseInt(input);
			
			
			avg = (grade1 + grade2 + grade3 + grade4 + grade5) / 
					numGrades;
					
			return avg;
		}
		
		public void modInts(int a, int b, int c, int d)
		{
			int e = 0; // compile error if not initialized
			System.out.println(a + b / c * d);  // 25
			System.out.println((a + b) / c + d);  // 25
			System.out.println(a * (c / b) * d);  // 25
			System.out.println((a + b) / (c * d));  // 25
			System.out.println(e + a);  // 25
			// System.out.println(e + A);  UNDEFINED VAR A -- compile
			//								error
			return;
		}
		
		public void modDoubles(double a, double b, double c,double d)
		{
			double e = 0; // compile error if not initialized
			System.out.println(a + b / c * d);  // 25
			System.out.println((a + b) / c + d);  // 25
			System.out.println(a * (c / b) * d);  // 25
			System.out.println((a + b) / (c * d));  // 25
			System.out.println(e + a);  // 25
			// System.out.println(e + A);  UNDEFINED VAR A -- compile
			//								error
			return;
		}
		
		public void useMath()
		{
			double a = 81, answer = 0.0;
			int b = 50, c = 67;
			
			
			System.out.println("NOW ILLUSTRATING Math Methods: "); 
			
			// LOG
			answer = Math.log(a);
			System.out.println("Log " + answer); 
			
			// Square Root
			answer = Math.sqrt(a);
			System.out.println("Sqr " + answer); 
			
			// Power
			answer = Math.pow(10, 2);
			System.out.println("Pwr " + answer); 
			
			//Sin
			answer = Math.sin(90);
			System.out.println("Sin " + answer); 
			
			//absolute value
			answer = Math.abs(-67);
			System.out.println("Abs " + answer); 
			
			//min
			answer = Math.min(b, c);
			System.out.println("Min " + answer); 
			
			//max
			answer = Math.max(b, c);
			System.out.println("Max " + answer); 
			
			return;
		}
	
	}

