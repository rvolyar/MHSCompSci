/*
 * findAddress.java
 *
 * Created on August 21, 2006, 2:47 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package arrays;

/**
 *
 * @author Dave
 */
public class findAddress {
    
    /** Creates a new instance of findAddress */
    public findAddress() 
    {
    }
    private int number ;
		private String name;
		
		public int getnumber()
		{
			return number;
		}
		
		public String getname()
		{
			return name;
		}
		public void setnumber(int x)
		{
			number = x;
		}
			
		public void setname(String s)
		{
			name = s;
		}
}
