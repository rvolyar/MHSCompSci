/*
 * address.java
 *
 * Created on August 21, 2006, 2:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package arrays;

/**
 *
 * @author Dave
 */
public class address {
    
    /** Creates a new instance of address */
    public address() 
    {
    }
    private int[] number ;
		private String[] name;
		
		public address()  // constructor to instantiate the arrays
		{
		name = new String[5];
		number = new int[5];
		}
		
		public void setdata(int p, String n, int ele)
		{
			number[ele] = p;
			name[ele] = n;
		}
		
		public int getnumber(int e)
		{
			return number[e];
		}
		
		public String getname(int e)
		{
			return name[e];
		}
}
