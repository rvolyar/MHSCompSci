package objectdrawplus;

import objectdraw.Rect;
import objectdraw.DrawingCanvas;
import objectdraw.Location;

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ODButton implements MouseListener
{
  private Rect buttonShape;
  private ArrayList listeners;

  public ODButton(Rect shape, DrawingCanvas canvas)
  {
    buttonShape = shape;
    canvas.addMouseListener(this);
    listeners = new ArrayList();
  }

  public Rect shape()
  {
    return buttonShape;
  }

  public void addButtonListener(ODButtonListener listener)
  {
    listeners.add(listener);
  }

  public void mouseClicked(MouseEvent e)
  {
    Location loc = new Location(e.getPoint());
    if(buttonShape.contains(loc)){
      for(int k = 0; k < listeners.size(); k++){
        ((ODButtonListener)listeners.get(k)).onButtonClick();
      }
    }
  }

  public void mousePressed(MouseEvent e)
  {
    Location loc = new Location(e.getPoint());
    if(buttonShape.contains(loc)){
      for(int k = 0; k < listeners.size(); k++){
        ((ODButtonListener)listeners.get(k)).onButtonPress();
      }
    }
  }

  public void mouseReleased(MouseEvent e)
  {
    Location loc = new Location(e.getPoint());
    if(buttonShape.contains(loc)){
      for(int k = 0; k < listeners.size(); k++){
        ((ODButtonListener)listeners.get(k)).onButtonRelease();
      }
    }
  }

   public void mouseEntered(MouseEvent e)
   {}

   public void mouseExited(MouseEvent e)
   {}
 }