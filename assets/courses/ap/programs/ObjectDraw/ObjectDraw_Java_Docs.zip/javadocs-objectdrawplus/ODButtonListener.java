package objectdrawplus;

import java.util.EventListener;

public interface ODButtonListener extends EventListener
{
  public void onButtonClick();

  public void onButtonPress();

  public void onButtonRelease();
}