package objectdrawplus;

public class ODButtonAdapter implements ODButtonListener
{
  public void onButtonClick()
  {}

  public void onButtonPress()
  {}

  public void onButtonRelease()
  {}
}