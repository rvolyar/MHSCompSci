/*
 * Main.java
 *
 * Created on March 6, 2007, 12:29 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package pq;
import java.util.PriorityQueue;
import java.util.Iterator;

/**
 *
 * @author Dave
 */
public class Main {
    
    /** Creates a new instance of Main */
  
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        PriorityQueue<String> P = new PriorityQueue<String>(10);
        
        P.add("Sally");
        P.add("Betty");
        P.add("Xavier");
        P.add("Teresa");
        P.add("David");
        
        
        if(P.isEmpty())
        {
         System.out.println("QUEUE IS EMPTY");
        }
        else
        {
            System.out.println(P.size());
        }
        
        P.remove();
        System.out.println(P.peek());
        
        Iterator i = P.iterator();
	i = P.iterator();
      
        
        while(i.hasNext())
        {
            System.out.println(i.next());
        }
        System.out.println();
        for(String x:P)
        {
            System.out.println(x.toString());
        }
    }
}    
