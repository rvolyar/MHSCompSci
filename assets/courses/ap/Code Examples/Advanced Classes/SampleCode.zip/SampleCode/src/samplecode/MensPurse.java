/*
 * MensPurse.java
 *
 * Created on August 28, 2006, 9:56 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package samplecode;

/**
 *
 * @author Dave
 */
public class MensPurse extends Purse
{
	// class stuff here
}