/*
 * Top.java
 *
 * Created on August 28, 2006, 9:53 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package samplecode;

// POSTCONDITION: Return the HIGHEST valued "SuperObject" in the Purse
public interface Top 
{
    double getTop( );
}
