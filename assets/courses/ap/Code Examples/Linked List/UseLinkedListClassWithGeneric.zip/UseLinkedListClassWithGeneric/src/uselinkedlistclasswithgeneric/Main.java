/*
 * Main.java
 *
 * Created on December 3, 2006, 2:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package uselinkedlistclasswithgeneric;
import java.util.NoSuchElementException;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;

/**
 *
 * @author Dave
 */
public class Main 
{
    
   
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        AirFlight f1 = new AirFlight("Atlanta", 100);
	AirFlight f2 = new AirFlight("Orlando", 500);
	AirFlight f3 = new AirFlight("Kennedy", 350);
	AirFlight f4 = new AirFlight("Newark", 300);
	AirFlight f5 = new AirFlight("Utah", 400);
	AirFlight f6 = new AirFlight("Houston", 200);
	AirFlight f7 = new AirFlight("Chicago", 860);
       
       // This class utilizes a Doubly Linked List

	LinkedList <AirFlight> ll = new LinkedList<AirFlight>();
        
    	ll.add(f1);
	ll.add(f2);
	ll.add(f3);
	ll.add(f4);
	ll.add(f5);
	ll.add(f6);
	ll.add(f7);
        
        
        System.out.println();
	System.out.println("Print the elements of LinkedList Using Java Class & Iterator");
	System.out.println();
	System.out.println("There are " + ll.size() + " Nodes in the List  A O K N U H C");
	
	printLL(ll);
        
        
         System.out.println();
	System.out.println("Print the elements of LinkedList Using the FOR EACH LOOP");
	System.out.println();
	System.out.println("There are " + ll.size() + " Nodes in the List  A O K N U H C");
       
        printLLFOREACH(ll);
        
        System.out.println();
	System.out.println("Print the elements of AGAIN Using the FOR EACH LOOP");
	System.out.println();
	System.out.println("There are " + ll.size() + " Nodes in the List  A O K N U H C");
       // USES fOR EACH LOOP AGAIN
        for(AirFlight r:ll)
		{
		// display list with newark removed
		System.out.println(r.toString());
		}
        // TRAVERSE USING LIST ITERATOR 
        
        System.out.println();
	System.out.println("Print the elements of AGAIN PASSING a LIST");
	System.out.println();
        
        printLLITERATOR((List)ll);
    }
    
    
    //  ITERATE USING THE STANDARD ITERATOR
    static public void printLL(List ll)
	{
		Iterator iter = ll.iterator();
		iter = ll.iterator();
		while(iter.hasNext())
		{
		// display list with newark removed
		System.out.println(iter.next());
		}
	}
     

//  ITERATE USING THE FOR EACH LOOP
    static public void printLLFOREACH(LinkedList ll)
	{
		//Iterator iter = ll.iterator();
		//iter = ll.iterator();
		LinkedList<AirFlight> lll = ll; 
                
               for(AirFlight r:lll)
		{
		// display list with newark removed
		System.out.println(r.toString());
		}
	}
    
    static public void printLLITERATOR(List<AirFlight> ll)
	{
		//Iterator iter = ll.iterator();
		//iter = ll.iterator();
		//LinkedList<AirFlight> lll = ll; 
                
               for(AirFlight r:ll)
		{
		// display list with newark removed
		System.out.println(r.toString());
		}
               System.out.println(" AND TRAVERSE WITH AN ITERATOR...");
               // NOW ITERATE using an iterator
               for(Iterator<AirFlight> itr = ll.iterator(); itr.hasNext();)
               {
                   System.out.println(itr.next());
               }
               
	}
    
}
