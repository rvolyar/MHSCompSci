/*
 * Purse.java
 *
 * Created on August 28, 2006, 9:55 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package newpurse;
import java.util.ArrayList;
/**
 *
 * @author Dave
 */
public class Purse 
{
	private double sum;
	private int count = 0;
	private Top max;
	private ArrayList myArray;
	
	public Purse ()
	{
		myArray = new ArrayList(100); 
		// initial capacity of 100 objects
								
	}
	
	public void add(Top ci)  
	{ 
		 // code here 
		if (count == 0 ||  max.getTop() < ci.getTop() )
		{
			max = ci;
		}
		count++;
		sum += ci.getTop();
		// added for arraylist
		// add new "coin" or "TC" superobject to list
		myArray.add(ci);
		
	}
	
	public double getTotal()  
	{  
		return sum; 
	}
	
	public Top  getTop()
	{
		return max;
	}
	
	public int getCount()
	{
		// return count;
		return myArray.size();
	}
	
	public Object getElement(int i)
	{
		return myArray.get(i);
	} 
	
	public Object RemoveElement(int i)
	{
		return myArray.remove(i);
	} 
	
	public Object setElement(int e, Object o)
	{
		return myArray.set(e, o);
	}
	
	public String toString()
	{
		String s = " ";
		
		for(int x = 0; x < myArray.size(); x++)
		{
			
			s += ((SuperObject)myArray.get(x)).toString();
			s += " ";
		} 
		return s;
	}
	
}
