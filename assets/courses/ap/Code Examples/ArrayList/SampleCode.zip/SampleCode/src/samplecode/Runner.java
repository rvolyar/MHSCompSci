/*
 * Runner.java
 *
 * Created on August 29, 2006, 8:25 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package samplecode;

/**
 *
 * @author Dave
 */
public class Runner 
{
    private String name;
    private int hoursTrained;
    /** Creates a new instance of Runner */
    public Runner() 
    {
        name = "Sally Joe Bob";
        hoursTrained = 23;
    }
    public int getHoursTrained()
    {
     return hoursTrained;   
    }
    
}
